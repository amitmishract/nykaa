let page = 2;
let str=""
function fetchData() {
  fetch("./products-dataset.json")
    .then((response) => (json = response.json()))
    .then((res) => {
        console.log(res)
      if (res.length && page <= Math.floor(res.length / 10)) {
        showProducts(res.filter(product=>{
            return product.title.includes(str);
        }).splice(0, page * 10));
        page++;
      }
    });
}

function search(e){
   
   str= document.getElementById("input").value || ""
   page=2
   fetchData()
}

function showProducts(data) {
//   console.log(data)
   
  let products = document.getElementById("products");
  products.innerHTML=""
  if(!data.length) return  false
  data.forEach((element) => {
    //   console.log(element)
    let item = document.createElement("div");
    item.classList.add("list_item");
    var x = document.createElement("IMG");
    x.setAttribute("src", element.imageUrl);
    x.setAttribute("width", "100%");
    x.setAttribute("height", "140px");
    item.appendChild(x);
    let p1 = document.createElement("p");
    p1.innerHTML = element.title;
    let p2 = document.createElement("p");
    p2.innerHTML = "description";
    let p3 = document.createElement("p");
    p3.innerHTML = element.sizeVariation.map((size) => size.title).join(", ");
    item.appendChild(p1);
    item.appendChild(p2);
    item.appendChild(p3);
    products.appendChild(item);
  });
}

window.onscroll = function (ev) {
  if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
    fetchData();
  }
};


function backToTop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0; 
}

fetchData();
